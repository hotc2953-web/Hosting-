import os
import sys
import json
import shutil
import zipfile
import logging
import asyncio
import subprocess
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardMarkup, KeyboardButton
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    ConversationHandler,
    CallbackQueryHandler,
    CallbackContext,
    filters,
)

# --- Configuration Loading ---
def load_config():
    try:
        with open("config.json", 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        print("FATAL: config.json not found! Please create it.")
        sys.exit(1)
    except json.JSONDecodeError:
        print("FATAL: config.json is not valid JSON!")
        sys.exit(1)

config = load_config()

# --- Constants from Config ---
ADMIN_BOT_TOKEN = config.get("ADMIN_BOT_TOKEN")
SUPER_ADMIN_ID = config.get("SUPER_ADMIN_ID")
DATA_FOLDER = config.get("DATA_FOLDER", "data")
BOTS_DATA_FILE = os.path.join(DATA_FOLDER, config.get("BOTS_DATA_FILE", "bots.json"))
ADMIN_FILE = os.path.join(DATA_FOLDER, config.get("ADMINS_FILE", "admins.json"))
MAX_LOG_LINES = config.get("MAX_LOG_LINES", 100)
RESTART_EXIT_CODE = 10

# --- Conversation States ---
(GET_BOT_NAME, GET_ZIP_FILE, GET_ADMIN_ID_TO_ADD) = range(3)

# --- Global Variables ---
bots = {}
admin_list = []
pending_requests = {}
application: Application = None 
RESTART_REQUESTED = False

# --- CACHE TIMER VARIABLES (30 Minutes = 1800 Seconds) ---
AUTO_CLEAR_INTERVAL = 1800 
CACHE_TIMER = AUTO_CLEAR_INTERVAL 

# --- Logging Setup ---
logging.basicConfig(format="%(asctime)s - %(name)s - %(levelname)s - %(message)s", level=logging.INFO)
logger = logging.getLogger(__name__)

# --- Helper Functions ---
def ensure_data_folder():
    os.makedirs(DATA_FOLDER, exist_ok=True)
    os.makedirs("bots", exist_ok=True)

def save_admins():
    with open(ADMIN_FILE, 'w') as f: json.dump(admin_list, f)
    logger.info("Admin list saved.")

def load_admins():
    global admin_list
    try:
        if os.path.exists(ADMIN_FILE):
            with open(ADMIN_FILE, 'r') as f: admin_list = json.load(f)
        if SUPER_ADMIN_ID not in admin_list:
            admin_list.append(SUPER_ADMIN_ID)
            save_admins()
        logger.info(f"Loaded {len(admin_list)} admins.")
    except Exception:
        admin_list = [SUPER_ADMIN_ID]

def is_admin(user_id: int) -> bool:
    return user_id in admin_list

def save_bot_data():
    bots_to_save = {name: {'folder_path': info['folder_path'], 'main_py': info['main_py']} for name, info in bots.items()}
    with open(BOTS_DATA_FILE, 'w') as f: json.dump(bots_to_save, f, indent=4)
    logger.info("Bot data saved.")

def load_bot_data():
    global bots
    if not os.path.exists(BOTS_DATA_FILE): return
    try:
        with open(BOTS_DATA_FILE, 'r') as f:
            loaded_bots = json.load(f)
            if not isinstance(loaded_bots, dict): return
            for name, info in loaded_bots.items():
                if isinstance(info, dict):
                    info['process'] = None
                    bots[name] = info
    except (json.JSONDecodeError, TypeError):
        bots = {}

# --- CORE FUNCTION: CLEAR DATA LOGIC ---
def perform_data_cleanup():
    """Clears specific logs and json files for all bots."""
    FILES_TO_CLEAR = [
        "stderr.log", 
        "stdout.log", 
        "bot.log", 
        "sent_otp.json", 
        "otp_tracking.json"
    ]
    
    count = 0
    try:
        for name, info in bots.items():
            folder_path = info.get('folder_path')
            
            if not folder_path or not os.path.exists(folder_path):
                continue

            # 1. Clear files from disk directly
            for filename in FILES_TO_CLEAR:
                file_path = os.path.join(folder_path, filename)
                if os.path.exists(file_path):
                    try:
                        # JSON ফাইল হলে {} লিখবো, বাকি ফাইল (log) হলে খালি করে দিবো
                        if filename.endswith(".json"):
                            with open(file_path, 'w', encoding='utf-8') as f:
                                f.write("{}")
                        else:
                            with open(file_path, 'w', encoding='utf-8') as f:
                                f.write("")
                        count += 1
                    except Exception as e:
                        logger.error(f"Could not clear {filename} for bot {name}: {e}")

            # 2. Clear open file handles if bot is running (stdout/stderr)
            if info.get('stdout_log') and not info['stdout_log'].closed:
                info['stdout_log'].truncate(0)
                info['stdout_log'].seek(0)
            
            if info.get('stderr_log') and not info['stderr_log'].closed:
                info['stderr_log'].truncate(0)
                info['stderr_log'].seek(0)
        
        return True
    except Exception as e:
        logger.error(f"Error in data cleanup: {e}")
        return False

# --- Background Task Loop ---
async def cache_cleanup_loop(app: Application):
    """Background task to count down and clear logs/json files."""
    global CACHE_TIMER
    logger.info(f"Starting Auto-Clear Cache Loop (Interval: {AUTO_CLEAR_INTERVAL}s)...")
    
    while True:
        if CACHE_TIMER > 0:
            CACHE_TIMER -= 1
        else:
            # Timer hit 0, clear logs and files
            perform_data_cleanup()
            # Reset Timer
            CACHE_TIMER = AUTO_CLEAR_INTERVAL
            # logger.info("Auto-cleared bot data files.")
        
        await asyncio.sleep(1)

# --- Reply Keyboard ---
def get_main_reply_markup(user_id: int) -> ReplyKeyboardMarkup:
    keyboard = [
        [KeyboardButton("➕ Add New Bot"), KeyboardButton("🤖 View Your Bots")],
    ]
    if user_id == SUPER_ADMIN_ID:
        keyboard.append([KeyboardButton("⚙️ Admin Panel")])
    return ReplyKeyboardMarkup(keyboard, resize_keyboard=True)

# --- START OF FUNCTION DEFINITIONS ---

async def start_command(update: Update, context: CallbackContext) -> None:
    user = update.effective_user
    user_id = user.id
    
    if is_admin(user_id):
        reply_markup = get_main_reply_markup(user_id)
        await update.message.reply_text(
            f"👋 Welcome back, {user.first_name}!\nPlease use the buttons below to manage your bots.",
            reply_markup=reply_markup
        )
    else:
        keyboard = [[InlineKeyboardButton("Authorize Request", callback_data=f"request_auth_{user_id}")]]
        reply_markup = InlineKeyboardMarkup(keyboard)
        await update.message.reply_text(
            "You are not an authorized admin.",
            reply_markup=reply_markup
        )

async def handle_auth_request(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    user = query.from_user
    user_id = user.id
    await query.answer()

    if user_id in pending_requests:
        await query.edit_message_text("Your access request is already pending. Please wait.")
        return
    if is_admin(user_id):
        await query.edit_message_text("You are already an authorized admin. Please type /start again.")
        return

    pending_requests[user_id] = user.full_name
    
    approval_keyboard = [
        [
            InlineKeyboardButton("✅ Approve", callback_data=f"approve_{user_id}"),
            InlineKeyboardButton("❌ Reject", callback_data=f"reject_{user_id}")
        ]
    ]
    approval_markup = InlineKeyboardMarkup(approval_keyboard)
    
    admin_message = (
        f"🔔 New Access Request\n\n"
        f"**User:** {user.full_name}\n"
        f"**ID:** `{user_id}`\n"
        f"**Username:** @{user.username or 'N/A'}\n\n"
        f"Do you want to grant them admin access?"
    )
    
    try:
        await context.bot.send_message(
            chat_id=SUPER_ADMIN_ID, 
            text=admin_message, 
            reply_markup=approval_markup,
            parse_mode='Markdown'
        )
        await query.edit_message_text("✅ Your request has been sent to the owner for approval. You will be notified of their decision.")
    except Exception as e:
        logger.error(f"Failed to send approval request to super admin: {e}")
        await query.edit_message_text("❌ Could not send the request. Please contact the bot owner directly.")


async def clear_data_command(update: Update, context: CallbackContext) -> None:
    if update.effective_user.id != SUPER_ADMIN_ID: return
    stop_all_bots()
    if os.path.isdir("bots"): shutil.rmtree("bots")
    if os.path.isdir(DATA_FOLDER): shutil.rmtree(DATA_FOLDER)
    bots.clear()
    ensure_data_folder()
    await update.message.reply_text("✅ All bot data, files, and logs have been successfully deleted.")

async def show_admin_panel(update: Update, context: CallbackContext) -> None:
    # Check admin again just in case
    if not is_admin(update.effective_user.id):
        await update.message.reply_text("❌ Access Denied: You are not an admin.")
        return

    # Calculate remaining time in minutes
    mins_left = CACHE_TIMER // 60
    secs_left = CACHE_TIMER % 60

    keyboard = [
        [InlineKeyboardButton("➕ Add Admin", callback_data="add_admin_start")],
        [InlineKeyboardButton("➖ Remove Admin", callback_data="remove_admin_list")],
        [InlineKeyboardButton("🗑️ Clear Data Logs", callback_data="manual_clear_logs")], # NEW BUTTON
        [InlineKeyboardButton("📋 List Admins", callback_data="list_admins")],
        [InlineKeyboardButton("🔄 Restart Bot", callback_data="restart_admin_bot"),
         InlineKeyboardButton("🛑 Shutdown Bot", callback_data="shutdown_admin_bot")]
    ]
    
    message_text = (
        f"⚙️ **Admin Panel**\n"
        f"──────────────────\n"
        f"⏳ Auto Clear: `{mins_left}m {secs_left}s` left\n"
        f"👥 Admins: `{len(admin_list)}`\n"
        f"🤖 Active Bots: `{len(bots)}`"
    )

    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(message_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
    else:
        await update.message.reply_text(message_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def list_admins(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    await query.answer()
    admin_text = "📋 **Current Admins:**\n" + "".join([f"- `{admin_id}`" + (" (Super Admin)" if admin_id == SUPER_ADMIN_ID else "") + "\n" for admin_id in admin_list])
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="admin_panel")]]
    await query.edit_message_text(admin_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def add_admin_start(update: Update, context: CallbackContext) -> int:
    query = update.callback_query
    await query.answer()
    keyboard = [[InlineKeyboardButton("⬅️ Back", callback_data="admin_panel")]]
    await query.edit_message_text("Please send the User ID of the new admin.", reply_markup=InlineKeyboardMarkup(keyboard))
    return GET_ADMIN_ID_TO_ADD

async def get_admin_id(update: Update, context: CallbackContext) -> int:
    if not is_admin(update.effective_user.id): return ConversationHandler.END
    try:
        new_admin_id = int(update.message.text)
        if new_admin_id not in admin_list:
            admin_list.append(new_admin_id)
            save_admins()
            await update.message.reply_text(f"✅ Admin `{new_admin_id}` added successfully.", parse_mode='Markdown')
        else:
            await update.message.reply_text(f"User `{new_admin_id}` is already an admin.", parse_mode='Markdown')
    except ValueError:
        await update.message.reply_text("Invalid User ID. Please send a numeric ID.")
    
    await start_command(update, context)
    return ConversationHandler.END

async def remove_admin_list(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    await query.answer()
    keyboard = [[InlineKeyboardButton(str(admin_id), callback_data=f"do_remove_admin_{admin_id}")] for admin_id in admin_list if admin_id != SUPER_ADMIN_ID]
    keyboard.append([InlineKeyboardButton("⬅️ Back", callback_data="admin_panel")])
    await query.edit_message_text("Select an admin to remove:", reply_markup=InlineKeyboardMarkup(keyboard))

async def show_bot_list(update: Update, context: CallbackContext) -> None:
    user_id = update.effective_user.id
    if not is_admin(user_id): 
        await update.message.reply_text("❌ Access Denied: You are not an admin.")
        return

    text = "Your registered bots:"
    if not bots:
        text = "No bots have been added yet."
        keyboard = [[InlineKeyboardButton("➕ Add a Bot Now", callback_data="add_new_bot")]]
    else:
        keyboard = [[InlineKeyboardButton(f"{'🟢' if info.get('process') and info['process'].poll() is None else '🔴'} {name}", callback_data=f"manage_bot_{name}")] for name, info in bots.items()]

    reply_markup = InlineKeyboardMarkup(keyboard)

    if update.callback_query:
        await update.callback_query.answer()
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup)
    else:
        await update.message.reply_text(text, reply_markup=reply_markup)

async def show_manage_menu(update: Update, context: CallbackContext, bot_name: str) -> None:
    query = update.callback_query
    await query.answer()
    if bot_name not in bots: return
    
    is_running = bots[bot_name].get('process') and bots[bot_name]['process'].poll() is None
    status_text = "🟢 Running" if is_running else "🔴 Stopped"
    
    # Time left
    mins_left = CACHE_TIMER // 60
    
    manage_text = (
        f"**Managing Bot: `{bot_name}`**\n"
        f"Current Status: {status_text}\n"
        f"⏳ Auto Clear in: **{mins_left} mins**"
    )

    keyboard = []
    if is_running:
        keyboard.append([InlineKeyboardButton("🛑 Stop", callback_data=f"stop_{bot_name}"), InlineKeyboardButton("🔄 Restart", callback_data=f"restart_{bot_name}")])
    else:
        keyboard.append([InlineKeyboardButton("▶️ Start", callback_data=f"start_{bot_name}")])
    keyboard.append([InlineKeyboardButton("📄 View Logs", callback_data=f"viewlogs_{bot_name}")])
    keyboard.append([InlineKeyboardButton("🗑️ Remove Bot", callback_data=f"confirmremove_{bot_name}")])
    keyboard.append([InlineKeyboardButton("⬅️ Back to List", callback_data="view_bot_list")])
    
    await query.edit_message_text(manage_text, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def add_bot_start(update: Update, context: CallbackContext) -> int:
    if update.callback_query:
        await update.callback_query.answer()
        message = update.callback_query.message
    else:
        message = update.message

    if not is_admin(update.effective_user.id):
        await message.reply_text("Unauthorized.")
        return ConversationHandler.END

    await message.reply_text("Please provide a name for your new bot (without spaces):")
    return GET_BOT_NAME

async def get_bot_name(update: Update, context: CallbackContext) -> int:
    if not is_admin(update.effective_user.id): return ConversationHandler.END
    bot_name = update.message.text.strip()
    if ' ' in bot_name:
        await update.message.reply_text("Bot name cannot contain spaces. Please try again.")
        return GET_BOT_NAME
    context.user_data['new_bot_name'] = bot_name
    await update.message.reply_text("✅ Name has been set.\n\nNow, send the .zip file with the bot's code.\n(Tip: Include a `requirements.txt` file for dependencies.)")
    return GET_ZIP_FILE

async def get_zip_file(update: Update, context: CallbackContext) -> int:
    if not is_admin(update.effective_user.id): return ConversationHandler.END
    bot_name = context.user_data.pop('new_bot_name', None)
    if not bot_name:
        await update.message.reply_text("Error: Conversation timed out. Please start again.")
        return ConversationHandler.END
    document = update.message.document
    if not document or not document.file_name.endswith('.zip'):
        await update.message.reply_text("Please send a .zip file.")
        return GET_ZIP_FILE
    file = await document.get_file()
    bot_folder_path = os.path.join("bots", bot_name)
    if os.path.exists(bot_folder_path): shutil.rmtree(bot_folder_path)
    os.makedirs(bot_folder_path)
    zip_path = os.path.join(bot_folder_path, f"{bot_name}.zip")
    await file.download_to_drive(zip_path)
    with zipfile.ZipFile(zip_path, 'r') as zip_ref: zip_ref.extractall(bot_folder_path)
    os.remove(zip_path)

    found_main_py = None
    py_files = []
    for root, _, files in os.walk(bot_folder_path):
        for f in files:
            if f.endswith(".py"):
                py_files.append(os.path.relpath(os.path.join(root, f), bot_folder_path))

    priority_list = [f"{bot_name.lower()}.py", "main.py", "bot.py", "app.py"]
    for priority_name in priority_list:
        for py_file in py_files:
            if os.path.basename(py_file).lower() == priority_name:
                found_main_py = py_file
                break
        if found_main_py: break
    
    if not found_main_py and len(py_files) == 1:
        found_main_py = py_files[0]

    if found_main_py:
        bots[bot_name] = {'folder_path': bot_folder_path, 'process': None, 'main_py': found_main_py}
        save_bot_data()
        await update.message.reply_text(f"✅ Bot '{bot_name}' added successfully. Identified `{found_main_py}` as main file.")
    else:
        shutil.rmtree(bot_folder_path)
        await update.message.reply_text("❌ Error: Could not find a suitable main Python file (like main.py, bot.py, etc.).")
    
    await start_command(update, context)
    return ConversationHandler.END

async def cancel_conv(update: Update, context: CallbackContext) -> int:
    await update.message.reply_text("Operation cancelled.")
    await start_command(update, context)
    return ConversationHandler.END

async def restart_admin_bot(update: Update, context: CallbackContext) -> None:
    global RESTART_REQUESTED
    query = update.callback_query
    await query.edit_message_text("🔄 **Restarting...**\nThis will take a moment.", parse_mode='Markdown')
    logger.info("Admin bot restart initiated.")
    RESTART_REQUESTED = True
    if application:
        asyncio.create_task(application.shutdown())

async def shutdown_admin_bot(update: Update, context: CallbackContext) -> None:
    query = update.callback_query
    await query.edit_message_text("🛑 **Shutting down...**\nGood bye!", parse_mode='Markdown')
    logger.info("Admin bot shutdown initiated.")
    if application:
        asyncio.create_task(application.shutdown())

def stop_all_bots():
    logger.info("Stopping all managed bots before exit...")
    for bot_name, info in bots.items():
        if info.get('process') and info['process'].poll() is None:
            logger.info(f"Terminating bot '{bot_name}'.")
            if info.get('stdout_log'): info['stdout_log'].close()
            if info.get('stderr_log'): info['stderr_log'].close()
            info['process'].terminate()
            info['process'].wait()

async def view_logs(update: Update, context: CallbackContext, bot_name: str) -> None:
    query = update.callback_query
    await query.answer()
    info = bots.get(bot_name)
    if not info: return

    log_content, log_type = "", "No logs found"
    try:
        stderr_path = os.path.join(info['folder_path'], 'stderr.log')
        if os.path.exists(stderr_path) and os.path.getsize(stderr_path) > 0:
            log_type = "Errors (stderr.log)"
            with open(stderr_path, 'r', encoding='utf-8') as f:
                lines = f.readlines()
                log_content = "".join(lines[-MAX_LOG_LINES:])
        else:
            stdout_path = os.path.join(info['folder_path'], 'stdout.log')
            if os.path.exists(stdout_path) and os.path.getsize(stdout_path) > 0:
                log_type = "Output (stdout.log)"
                with open(stdout_path, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    log_content = "".join(lines[-MAX_LOG_LINES:])
    except Exception as e:
        log_content = f"Could not read log file: {e}"

    message = f"**Logs for `{bot_name}`**\n__{log_type}__:\n\n"
    if log_content:
        message += f"```{log_content}```"
    else:
        message += "The bot may not have started or produced any output."
    
    keyboard = [[InlineKeyboardButton("⬅️ Back to Manage Menu", callback_data=f"manage_bot_{bot_name}")]]
    await query.edit_message_text(message, reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')

async def button_handler(update: Update, context: CallbackContext) -> None:
    global CACHE_TIMER
    query = update.callback_query
    user_id = query.from_user.id
    data = query.data
    
    # Handle manual data clearing
    if data == "manual_clear_logs":
        if not is_admin(user_id):
            await query.answer("Unauthorized.", show_alert=True)
            return
        
        perform_data_cleanup()
        CACHE_TIMER = AUTO_CLEAR_INTERVAL # Reset Timer
        await query.answer("✅ All logs & data cleared! Timer reset to 30m.", show_alert=True)
        # Refresh the admin panel to show updated timer if desired, or let user do it
        await show_admin_panel(update, context)
        return

    await query.answer() # Acknowledge other clicks

    if data.startswith("approve_") or data.startswith("reject_"):
        is_approve = data.startswith("approve_")
        target_user_id = int(data.split('_')[1])
        
        if user_id != SUPER_ADMIN_ID:
            await query.answer("This is not for you!", show_alert=True)
            return

        if target_user_id in pending_requests:
            user_name = pending_requests.pop(target_user_id)
            
            if is_approve:
                admin_list.append(target_user_id)
                save_admins()
                await query.edit_message_text(f"✅ User '{user_name}' (`{target_user_id}`) has been approved.", parse_mode='Markdown')
                notification_text = "🎉 Your access request has been approved!\n\nYou can now use /start to access the main menu."
            else:
                await query.edit_message_text(f"❌ User '{user_name}' (`{target_user_id}`) has been rejected.", parse_mode='Markdown')
                notification_text = "Sorry, your access request has been rejected."

            try:
                await context.bot.send_message(chat_id=target_user_id, text=notification_text)
            except Exception as e:
                logger.warning(f"Failed to notify user {target_user_id}: {e}")
        else:
            await query.edit_message_text("This request has already been handled.")
        return
        
    if not is_admin(user_id):
        await query.answer("You are not authorized for this action.", show_alert=True)
        return

    if data == "view_bot_list":
        await show_bot_list(update, context)
    elif data == "admin_panel":
        await show_admin_panel(update, context)
    elif data.startswith("manage_bot_"):
        await show_manage_menu(update, context, data.replace("manage_bot_", ""))
    elif data.startswith("viewlogs_"):
        await view_logs(update, context, data.replace("viewlogs_", ""))
    elif data in ["restart_admin_bot", "shutdown_admin_bot"]:
        if data == "restart_admin_bot": await restart_admin_bot(update, context)
        else: await shutdown_admin_bot(update, context)
    elif data.startswith("do_remove_admin_"):
        admin_id_to_remove = int(data.replace("do_remove_admin_", ""))
        if admin_id_to_remove in admin_list and admin_id_to_remove != SUPER_ADMIN_ID:
            admin_list.remove(admin_id_to_remove)
            save_admins()
            await query.answer(f"Admin {admin_id_to_remove} removed.")
        await remove_admin_list(update, context)
    elif data in ["add_admin_start", "list_admins", "remove_admin_list"]:
        if data == "add_admin_start": await add_admin_start(update, context)
        elif data == "list_admins": await list_admins(update, context)
        else: await remove_admin_list(update, context)
    else:
        parts = data.split('_', 1)
        if len(parts) != 2: return
        action, bot_name = parts
        
        info = bots.get(bot_name)
        if not info: return

        if action == "start" or action == "restart":
            if info.get('process') and info['process'].poll() is None:
                info['process'].terminate()
                info['process'].wait()
            
            requirements_path = os.path.join(info['folder_path'], 'requirements.txt')
            if os.path.exists(requirements_path):
                msg = await query.message.reply_text(f"⏳ Installing dependencies for `{bot_name}`...", parse_mode='Markdown')
                try:
                    subprocess.check_call([sys.executable, '-m', 'pip', 'install', '-r', requirements_path])
                    await msg.delete() # Delete "installing" message
                except subprocess.CalledProcessError:
                    await msg.edit_text(f"❌ Failed to install dependencies for `{bot_name}`. Check logs for details.")
                    return

            env = os.environ.copy()
            env["PYTHONUTF8"] = "1"
            stdout_log = open(os.path.join(info['folder_path'], 'stdout.log'), 'a+', encoding='utf-8')
            stderr_log = open(os.path.join(info['folder_path'], 'stderr.log'), 'a+', encoding='utf-8')
            
            info['process'] = subprocess.Popen(
                [sys.executable, "-u", info['main_py']], 
                cwd=info['folder_path'], 
                env=env, 
                stdout=stdout_log, 
                stderr=stderr_log
            )
            info['stdout_log'] = stdout_log
            info['stderr_log'] = stderr_log
            await query.answer(f"Bot '{bot_name}' {action}ed.")
            
        elif action == "stop":
            if info.get('process') and info['process'].poll() is None:
                info['process'].terminate()
                info['process'].wait()
                await query.answer(f"Bot '{bot_name}' stopped.")
        elif action == "confirmremove":
            keyboard = [[InlineKeyboardButton("✅ Yes, Delete", callback_data=f"doremove_{bot_name}")], [InlineKeyboardButton("❌ No, Cancel", callback_data=f"manage_bot_{bot_name}")]]
            await query.edit_message_text(f"Are you sure you want to permanently delete the bot `{bot_name}`?", reply_markup=InlineKeyboardMarkup(keyboard), parse_mode='Markdown')
        elif action == "doremove":
            if info.get('process') and info['process'].poll() is None:
                info['process'].terminate()
                info['process'].wait()
            if os.path.isdir(info['folder_path']): shutil.rmtree(info['folder_path'])
            bots.pop(bot_name)
            save_bot_data()
            await query.edit_message_text(f"✅ Bot '{bot_name}' has been successfully deleted.")
        
        await asyncio.sleep(1)
        await show_manage_menu(update, context, bot_name)

# --- Post Init to Start Background Task ---
async def post_init(app: Application):
    asyncio.create_task(cache_cleanup_loop(app))

def main() -> None:
    global application
    if not all([ADMIN_BOT_TOKEN, SUPER_ADMIN_ID]):
        logger.error("ADMIN_BOT_TOKEN and SUPER_ADMIN_ID must be set in config.json")
        return

    ensure_data_folder()
    load_bot_data()
    load_admins()
    
    application = Application.builder().token(ADMIN_BOT_TOKEN).post_init(post_init).build()
    
    add_admin_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(add_admin_start, pattern="^add_admin_start$")],
        states={GET_ADMIN_ID_TO_ADD: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_admin_id)]},
        fallbacks=[CommandHandler("cancel", cancel_conv)]
    )
    add_bot_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(add_bot_start, pattern="^add_new_bot$"),
            MessageHandler(filters.Regex(r"^➕ Add New Bot$"), add_bot_start)
        ],
        states={
            GET_BOT_NAME: [MessageHandler(filters.TEXT & ~filters.COMMAND, get_bot_name)],
            GET_ZIP_FILE: [MessageHandler(filters.Document.ZIP, get_zip_file)],
        },
        fallbacks=[CommandHandler("cancel", cancel_conv)],
    )

    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("cleardata", clear_data_command))
    
    # --- Regex Handlers ---
    application.add_handler(MessageHandler(filters.Regex(r"^🤖 View Your Bots$"), show_bot_list))
    application.add_handler(MessageHandler(filters.Regex(r"^⚙️ Admin Panel$"), show_admin_panel))
    
    application.add_handler(CallbackQueryHandler(handle_auth_request, pattern="^request_auth_"))
    
    application.add_handler(add_admin_conv)
    application.add_handler(add_bot_conv)
    application.add_handler(CallbackQueryHandler(button_handler))
    
    logger.info("Admin bot process started.")
    application.run_polling()
    
    stop_all_bots()
    if RESTART_REQUESTED:
        logger.info(f"Exiting with code {RESTART_EXIT_CODE} to signal a restart.")
        sys.exit(RESTART_EXIT_CODE)
    else:
        logger.info("Admin bot process has been shut down normally.")

if __name__ == "__main__":
    main()